 
# :money_with_wings: ShinobuClipper
Replace any BTC, XMR, XLM, ETH, XRP, LTC, BCH, NEC, ZCASH, DASH, DOGE, WMR, WMG, WMZ, WMH, WMU, WMX, Yandex money, Qiwi addresses in clipboard.

# :star2: Info
 - [X] 9 kilobytes compiled executable
 - [X] No admininistrator rights required
 - [X] Hide file after start
 - [X] Open source
 - [X] Autorun

# :gear: Configuration file
<p align="center">
  <img src="https://i.ibb.co/GC5chXG/config.jpg">
</p>

